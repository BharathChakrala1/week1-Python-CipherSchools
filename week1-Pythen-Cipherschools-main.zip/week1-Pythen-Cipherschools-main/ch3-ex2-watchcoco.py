name=input("enter your name : ")
age=int(input("enter ur age : "))
if (name[0]=='A' or name[0]=="a") and age>=12:
    print("You can watch the coco movie ")
else:
    print("you cant watch the coco movie")