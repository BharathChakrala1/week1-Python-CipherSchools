name,age=input("enter ur name and age seperated with space :").split()
# to split valibles with space
name2,age2=input("enter ur name and age seperated with commas :").split(",")
# to split the variable with , 
print(name,name2,age,age2)