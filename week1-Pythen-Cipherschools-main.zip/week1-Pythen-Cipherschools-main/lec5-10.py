print("heeloo world")
print("helllo \"world\"satish")
print("hello\nsatish")
print("this is\ttab")