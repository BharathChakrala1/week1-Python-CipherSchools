a=int(input("how many number u wana sum : "))
total=0
i=1
while i<=a:
    total=total+i
    i=i+1

print(total)
    
    