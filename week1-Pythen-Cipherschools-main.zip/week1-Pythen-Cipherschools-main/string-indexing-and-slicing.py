a="kamleshsinghrathore"
print(a[4])
print(a[-4])
print(a[1:7])
print(a[-7:-3])