a=input("Enter your Name : ")
print("you name in reverse is ",a[::-1])