a="my name is satish kumar"
print(a[1:10])
print(a[1:10:2])
print(a[1::2])
