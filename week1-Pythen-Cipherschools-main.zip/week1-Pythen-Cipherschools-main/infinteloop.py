# kabhi kabhi jaan ke infinite loop use karte haii kabhi kabhi galti se use ho jata hai
i=0
while i<10:
    print("wada wao wao ")
# ye galti eala hai



while True:
    print("heelo")
    # ye hum jaan ke chalate hai