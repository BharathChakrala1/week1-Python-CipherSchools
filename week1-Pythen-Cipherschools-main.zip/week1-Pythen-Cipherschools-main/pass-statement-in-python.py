a="satish"
if "s" in a:
    pass
