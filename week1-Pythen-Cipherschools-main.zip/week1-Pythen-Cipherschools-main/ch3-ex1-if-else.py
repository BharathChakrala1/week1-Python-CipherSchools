b=int(input("guess number : "))
a=23
if a==b:
    print("you win ")

elif a>b:
    print("too low")
else:
    print("to high")