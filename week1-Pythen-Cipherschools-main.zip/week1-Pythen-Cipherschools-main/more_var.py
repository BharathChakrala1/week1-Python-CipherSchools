name,age="satish",21
print("my name is",name,"\n""i m",age,"years old")                