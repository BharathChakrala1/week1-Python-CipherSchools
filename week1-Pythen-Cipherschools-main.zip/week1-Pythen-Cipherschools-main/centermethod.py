name="satish"
print(name.center(10,"_"))