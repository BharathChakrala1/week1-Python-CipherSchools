a="hershit"
b="kumar"
full_name=a+b
print(full_name)
# we can add or cancatinate string with string otherwise it will give type error