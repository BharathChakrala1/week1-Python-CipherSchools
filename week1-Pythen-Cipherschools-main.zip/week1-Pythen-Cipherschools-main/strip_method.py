a="             satish kyummar      "
b="*******"
print(a.rstrip()+b)
print(a.lstrip()+b)
print(a.strip()+b)