a=input("enter the number : ")

b=len(a)
i=0
total=0
while i<b :
    total=total+int(a[i])
    i=i+1
print(total)
