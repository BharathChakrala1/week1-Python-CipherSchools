a=input("name")
b=int(input("age"))
print("hello  your name is {}. you are {} years old".format(a,b))
# this is in pythen 3
print(f"hello {a} you are {b} years old")