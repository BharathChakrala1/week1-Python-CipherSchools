name=input("Enter Your Name : ")
if name:
    print("you did not enter anything")
else:
    print("your name is name")
# if u see (if name:) jo likha hai wo check kar raha hai if name is empty than if ke andar wala print kar do