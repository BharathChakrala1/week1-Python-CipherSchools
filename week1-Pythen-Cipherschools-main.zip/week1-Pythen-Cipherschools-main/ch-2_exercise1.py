a=int(input())
b=int(input())
c=int(input())
d=a+b+c/3
print("numbers are {} {} {} and average is {}".format(a,b,c,d))