a="sAtish kumrr"
b="my name is satish kummar mishra"
if "a" in a:
    print("true")
else:
    print("false")