a=10
b=10
print(a==b)
# boolean ya tu true hote hai ya faklse