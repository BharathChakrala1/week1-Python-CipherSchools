a=input("enter name : ")
b=int(input("how many times u want to print ur name : "))
print(a*b)