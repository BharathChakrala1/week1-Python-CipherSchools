i=1
while i<10:
    print("heelo world",i)
    i=i+1