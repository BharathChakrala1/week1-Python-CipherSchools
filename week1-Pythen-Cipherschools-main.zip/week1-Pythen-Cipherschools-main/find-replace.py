a="she is so beautiful and she is cute also"

print("****** After Marriage   *********")
print(a.replace("is","was"))
print(a.find("is"))
print(a.find("is",a.find("is")+1))
